from django.contrib import admin
from .models import Tour, Roadmap, Order

# Register your models here.
admin.site.register(Tour)
admin.site.register(Roadmap)
admin.site.register(Order)