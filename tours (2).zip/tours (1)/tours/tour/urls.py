from django.urls import path, include
from .views import index, tour, tours, admin, about, register, profile, roadmap_detail, submit_review, activate, \
    guide_list, guide_detail
from django.contrib.auth import views as auth_views


urlpatterns = [
    path('', index, name='index'),
    path('tour/<int:tour_id>', tour, name='tour'),
    path('tours', tours, name='tours'),
    path('client/admin', admin, name='client_admin'),
    path('about', about, name='about'),
    path('register/', register, name='register'),
    path('login/', auth_views.LoginView.as_view(
        template_name='login.html',
        extra_context={'next': "/"}
    ), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('profile/', profile, name='profile'),
    path('roadmaps/<int:pk>/', roadmap_detail, name='roadmap_detail'),
    path('tour/<int:tour_id>/submit_review/', submit_review, name='submit_review'),
    path('activate/<uidb64>/<token>/', activate, name='activate'),

    path('guides/', guide_list, name='guide_list'),
    path('guides/<int:guide_id>/', guide_detail, name='guide_detail'),
]
from django.conf import settings
from django.conf.urls.static import static
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
