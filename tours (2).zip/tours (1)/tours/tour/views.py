from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect, get_object_or_404

from .forms import CustomUserCreationForm
from .models import Tour, Roadmap, Order, Review, Guide
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.template.loader import render_to_string
from django.utils.encoding import force_bytes, force_str
from django.contrib.sites.shortcuts import get_current_site
from django.core.mail import send_mail
from django.contrib.auth.tokens import default_token_generator
from django.http import HttpResponse
from django.conf import settings

def send_verification_email(request, user):
    token = default_token_generator.make_token(user)
    uidb64 = urlsafe_base64_encode(force_bytes(user.pk))
    current_site = get_current_site(request)
    mail_subject = 'Activate your account'
    message = render_to_string('email_verification.html', {
        'user': user,
        'domain': current_site.domain,
        'uid': uidb64,
        'token': token,
    })
    send_mail(mail_subject, message, settings.EMAIL_HOST_USER, [user.email])

def activate(request, uidb64, token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except(TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None

    if user is not None and default_token_generator.check_token(user, token):
        user.is_active = True
        user.save()
        return HttpResponse('Thank you for your email confirmation. Now you can login your account.')
    else:
        return HttpResponse('Activation link is invalid!')


def is_admin(user):
    return user.is_authenticated and user.is_staff


def index(request):
    return render(request, 'main.html', {'tours': Tour.objects.all()[:3]})


def tour(request, tour_id):
    if request.method == 'POST':
        try:
            user = request.user
        except:
            return redirect('login')
        order_object = Order()
        order_object.tour = Tour.objects.get(id=tour_id)
        order_object.user = user
        order_object.order_name = request.POST.get('name')
        order_object.order_phone = request.POST.get('phone')
        order_object.order_option = request.POST.get('option')
        order_object.save()
        return redirect('profile')
    else:
        tour_object = Tour.objects.get(id=tour_id)
        roadmaps = Roadmap.objects.filter(tour=tour_id)
    return render(request, 'tour.html', {'tour': tour_object, 'roadmaps': roadmaps})


def tours(request):
    max_price = request.GET.get('price')
    max_duration = request.GET.get('duration')
    date_from = request.GET.get('date')

    tours = Tour.objects.all()

    if max_price:
        tours = tours.filter(tour_price__lte=max_price)
    if max_duration:
        tours = tours.filter(tour_duration__lte=max_duration)
    if date_from:
        tours = tours.filter(next_date__gte=date_from)

    return render(request, 'tours.html', {'tours': tours})


@user_passes_test(is_admin, login_url='login')
def admin(request):
    if request.method == 'POST':
        order_id = request.POST.get('order_id')
        status = request.POST.get('status')
        order_object = Order.objects.get(id=order_id)
        order_object.order_successful = True if status == 'paid' else False
        order_object.save()
    return render(request, 'admin.html', {'orders': Order.objects.all()})


def about(request):
    return render(request, 'about.html')

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.is_active = False  # Deactivate account until it is confirmed
            user.save()
            send_verification_email(request, user)
            return HttpResponse('Please confirm your email address to complete the registration.')
    else:
        form = CustomUserCreationForm()
    return render(request, 'register.html', {'form': form})


@login_required
def profile(request):
    user_orders = Order.objects.filter(user=request.user)
    return render(request, 'profile.html', {'user': request.user, 'orders': user_orders})


def roadmap_detail(request, pk):
    roadmap = get_object_or_404(Roadmap, pk=pk)
    return render(request, 'roadmap.html', {'roadmap': roadmap})

@login_required
def submit_review(request, tour_id):
    if request.method == 'POST':
        user = request.user
        tour = Tour.objects.get(id=tour_id)
        title = request.POST.get('title')
        description = request.POST.get('description')

        review = Review(user=user, tour=tour, title=title, description=description)
        review.save()

        return redirect('tour', tour_id=tour_id)
    else:
        tour = Tour.objects.get(id=tour_id)
        return render(request, 'submit_review.html', {'tour': tour})



def guide_list(request):
    guides = Guide.objects.all()
    return render(request, 'guide_list.html', {'guides': guides})

def guide_detail(request, guide_id):
    guide = get_object_or_404(Guide, id=guide_id)
    return render(request, 'guide_detail.html', {'guide': guide})