from django.contrib import admin
from .models import Tour, Roadmap, Order, Review, Guide, GuidePhoto

# Register your models here.
admin.site.register(Tour)
admin.site.register(Roadmap)
admin.site.register(Order)
admin.site.register(Review)
admin.site.register(Guide)
admin.site.register(GuidePhoto)