from django.apps import AppConfig


class ParkingsystemConfig(AppConfig):
    name = 'parkingsystem'
