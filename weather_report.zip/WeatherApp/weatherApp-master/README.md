# weatherApp
create a simple spring boot weather application - openweather
# Postman
http://localhost:8080/weather/forecast?city=Qatar on the Qatar will be any citys check in https://openweathermap.org/
# Swagger UI
http://localhost:8080/swagger-ui.html#/weather-controller click try it out button to search a city's weather report
